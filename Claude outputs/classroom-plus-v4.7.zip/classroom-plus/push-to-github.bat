@echo off
cd /d "%~dp0"
echo === Classroom PLus : Commit and Push to GitHub ===
where git >nul 2>nul
if errorlevel 1 goto nogit
git config user.name >nul 2>nul
if errorlevel 1 git config --global user.name "KruPond"
git config user.email >nul 2>nul
if not errorlevel 1 goto haveemail
set /p EM=Type your GitHub email and press Enter: 
git config --global user.email "%EM%"
:haveemail
if not exist ".git" git init
git add -A
git commit -m "Classroom PLus v4: single-file Apps Script web app"
git branch -M main
git remote remove origin >nul 2>nul
git remote add origin https://github.com/krupondcompute/Classroom-Plus.git
echo Syncing with GitHub (local files win if both changed)...
git fetch origin main >nul 2>nul
if not errorlevel 1 git merge -X ours --allow-unrelated-histories -m "Merge GitHub changes" origin/main
echo.
echo Pushing... If a login window appears, choose "Sign in with your browser" and log in as krupondcompute.
git push -u origin main
if errorlevel 1 goto fail
echo.
echo *** SUCCESS: open https://github.com/krupondcompute/Classroom-Plus ***
pause
exit /b 0
:fail
echo.
echo *** PUSH FAILED - copy the messages above and send them to Claude ***
pause
exit /b 1
:nogit
echo Git is not installed. Install from https://git-scm.com/download/win then run this file again.
pause
exit /b 1
